package com.abobaker.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.security.SecureRandom;

public class MainActivity extends Activity {
    private final SecureRandom random = new SecureRandom();
    private EditText ssidInput;
    private TextView result;
    private static final String CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%";

    private int dp(float value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(color);
        if (bold) v.setTypeface(null, Typeface.BOLD);
        return v;
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(36), dp(24), dp(24));
        root.setBackgroundColor(Color.rgb(245, 248, 252));

        TextView title = text("abobaker", 30, Color.rgb(16, 42, 67), true);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = text("مولّد كلمة مرور Wi-Fi يعمل دون إنترنت", 16, Color.DKGRAY, false);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subP = new LinearLayout.LayoutParams(-1, -2);
        subP.topMargin = dp(10);
        root.addView(subtitle, subP);

        TextView label = text("SSID NAME", 14, Color.rgb(16, 42, 67), true);
        LinearLayout.LayoutParams labelP = new LinearLayout.LayoutParams(-1, -2);
        labelP.topMargin = dp(36);
        root.addView(label, labelP);

        ssidInput = new EditText(this);
        ssidInput.setSingleLine(true);
        ssidInput.setHint("اسم شبكتك");
        ssidInput.setTextSize(16);
        ssidInput.setPadding(dp(14), dp(12), dp(14), dp(12));
        root.addView(ssidInput, new LinearLayout.LayoutParams(-1, -2));

        Button generate = new Button(this);
        generate.setText("Get Passkey");
        LinearLayout.LayoutParams genP = new LinearLayout.LayoutParams(-1, -2);
        genP.topMargin = dp(22);
        root.addView(generate, genP);

        result = text("ستظهر كلمة المرور هنا", 20, Color.rgb(16, 42, 67), true);
        result.setGravity(Gravity.CENTER);
        result.setPadding(dp(12), dp(24), dp(12), dp(24));
        LinearLayout.LayoutParams resultP = new LinearLayout.LayoutParams(-1, -2);
        resultP.topMargin = dp(18);
        root.addView(result, resultP);

        Button copy = new Button(this);
        copy.setText("نسخ كلمة المرور");
        root.addView(copy, new LinearLayout.LayoutParams(-1, -2));

        TextView note = text("ملاحظة: ينشئ التطبيق كلمة مرور جديدة عشوائية لشبكتك. لا يستخرج كلمة مرور شبكة موجودة ولا يتصل بأي خدمة.", 13, Color.DKGRAY, false);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams noteP = new LinearLayout.LayoutParams(-1, -2);
        noteP.topMargin = dp(24);
        root.addView(note, noteP);

        generate.setOnClickListener(v -> {
            String ssid = ssidInput.getText().toString().trim();
            if (ssid.isEmpty()) {
                ssidInput.setError("اكتب اسم شبكتك أولاً");
                return;
            }
            StringBuilder password = new StringBuilder();
            for (int i = 0; i < 16; i++) {
                password.append(CHARS.charAt(random.nextInt(CHARS.length())));
            }
            result.setText(password.toString());
        });

        copy.setOnClickListener(v -> {
            String value = result.getText().toString();
            if (value.equals("ستظهر كلمة المرور هنا")) {
                Toast.makeText(this, "ولّد كلمة المرور أولاً", Toast.LENGTH_SHORT).show();
                return;
            }
            ClipboardManager clipboard = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("Wi-Fi password", value));
            Toast.makeText(this, "تم النسخ", Toast.LENGTH_SHORT).show();
        });

        setContentView(root);
    }
}
