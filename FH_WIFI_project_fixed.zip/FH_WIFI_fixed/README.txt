FH WIFI Android app

This is a WebView wrapper for https://fh-wlan.vercel.app/.
The original website provides the app's main functionality; this Android shell does not replace it.
External website navigation is blocked. The only intentional external link is the Instagram button for @vvvu._4.
Internet is required to load the website.

Build: gradle assembleDebug
APK: app/build/outputs/apk/debug/app-debug.apk
